MinecraftUtilities V-2.0

The MinecraftUtilities plugin is only useable in Minecraft Spigot Version 1.15.2.

The current utilities that are available are:

/hide : Allows the player to "sneak" without holding down the sneak key. The player will un-sneak if the command is ran again or the player presses the sneak key.

/trade <Amount of Diamonds> : Allows the player to trade one diamond for one xp level.

CHANGES:
(None)

BUGS:
- If player uses /hide and then unsneaks by pressing the sneak/crouch key, the player won't recieve a mesage saying that they are shown.
- If the player uses /hide, all the sneak actions (placing blocks on furnaces, crafting tables, chests) will happen. 